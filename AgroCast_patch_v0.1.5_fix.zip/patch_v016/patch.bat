@echo off
set /p TARGET="Путь к AgroCast (где AgroCast.exe), напр C:\AgroCast: "
copy /Y "%~dp0_internal\static\desktop.html" "%TARGET%\_internal\static\desktop.html"
copy /Y "%~dp0_internal\static\desktop.js" "%TARGET%\_internal\static\desktop.js"
echo Для полного фикса CSP нужен пересбор — скачайте v0.1.6 когда соберётся
echo Но карта уже будет работать с патчем!
pause
