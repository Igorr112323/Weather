@echo off
set /p TARGET="Путь к AgroCast (где AgroCast.exe), напр C:\AgroCast: "
copy /Y "%~dp0_internal\static\desktop.html" "%TARGET%\_internal\static\desktop.html"
copy /Y "%~dp0_internal\static\desktop.js" "%TARGET%\_internal\static\desktop.js"
echo Готово! Перезапустите AgroCast.exe
pause
