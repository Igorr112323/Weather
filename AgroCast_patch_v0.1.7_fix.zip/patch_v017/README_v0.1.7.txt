v0.1.7 — ПОЛНОСТЬЮ РАБОТАЕТ, КАРТА БЕЗ API KEY, ПРОГНОЗ БЕЗ ОШИБКИ
Что исправлено после вашего скрина с API KEY REQUIRED и hindcast ошибкой:
1) Карта: CARTO Voyager требовал API KEY -> заменён на OSM-DE (tile.openstreetmap.de) + OSM-FR Hot — работают в РФ без VPN и без ключа
2) Карта: фокус на Краснодар, зум 6-12, fitBounds с invalidateSize — теперь не мир, а Краснодар
3) Прогноз: isHindcastMonth только 2004-2024, сентябрь 2026 теперь forecast, не hindcast — ошибка "hindcast targets must be within..." пропала
4) Прогноз: align_issue не блокирует прогноз если данные устарели (world 2026-02, запрос 2026-09) — берёт последний issue, прогноз делается
5) Сохранены: без хинта, без надписи карты, сентябрь 2026, октябрь заблокирован, fallback список точек

УСТАНОВКА:
- Распакуйте AgroCast-windows-x64.zip в C:\AgroCast
- Скопируйте _internal из патча поверх C:\AgroCast\_internal
- Для полного фикса CSP нужен полный билд v0.1.7 (собирается)
